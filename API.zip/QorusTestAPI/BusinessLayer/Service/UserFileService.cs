﻿using Microsoft.WindowsAzure.Storage.Blob;
using QorusTestAPI.Context;
using QorusTestAPI.DataLayer.UnitOfWork;
using QorusTestAPI.DTO;
using QorusTestAPI.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace QorusTestAPI.BusinessLayer.Service
{
    public class UserFileService
    {
        private readonly UnitOfWork _unitOfWork;

        public UserFileService()
        {
            _unitOfWork = new UnitOfWork();
        }

        public IEnumerable<UserFile> GetAllFiles()
        {
            var UserFiles = _unitOfWork.UserFileRepository.GetAll().ToList();
            if (UserFiles.Any())
            {
                return UserFiles;
            }
            return new List<UserFile>();
        }

        public async Task<bool> CreateFile(HttpPostedFile FileObj, string Category, DateTime LastReviewed)
        {
            byte[] fileData = null;
            using (var binaryReader = new BinaryReader(FileObj.InputStream))
            {
                fileData = binaryReader.ReadBytes(FileObj.ContentLength);
            }

            var customFile = new CustomFile
            {
                FileBytes = fileData,
                FileMime = FileObj.ContentType,
                FileName = FileObj.FileName
            };
            await UploadFileToBlob(customFile);

            var UserFile = new UserFile
            {
                Category = Category,
                FileName = customFile.FileName,
                FileSize = FileObj.ContentLength,
                LastReviewed = LastReviewed
            };

            _unitOfWork.UserFileRepository.Insert(UserFile);
            return true;
        }


        private async Task<bool> UploadFileToBlob(CustomFile file)
        {
            // Get Blob Container
            CloudBlobContainer container = BlobUtilities.GetBlobClient.GetContainerReference("documents");
            container.CreateIfNotExists();

            // Get reference to blob (binary content)
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(file.FileName);

            // set its properties
            blockBlob.Properties.ContentType = file.FileMime;
            blockBlob.Metadata["filename"] = file.FileName;
            blockBlob.Metadata["filemime"] = file.FileMime;

            // Get stream from file bytes
            Stream stream = new MemoryStream(file.FileBytes);

            // Async upload of stream to Storage
            AsyncCallback UploadCompleted = new AsyncCallback(OnUploadCompleted);
            blockBlob.BeginUploadFromStream(stream, UploadCompleted, blockBlob);

            return true;
        }

        private void OnUploadCompleted(IAsyncResult result)
        {
            CloudBlockBlob blob = (CloudBlockBlob)result.AsyncState;
            blob.SetMetadata();
            blob.EndUploadFromStream(result);
        }
    }
}