﻿using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace QorusTestAPI.BusinessLayer
{
    public class UserFileBL
    {
        public async Task<bool> UploadFileToBlob(CustomFile file)
        {
            // Get Blob Container
            CloudBlobContainer container = BlobUtilities.GetBlobClient.GetContainerReference("documents");
            container.CreateIfNotExists();

            // Get reference to blob (binary content)
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(file.FileName);

            // set its properties
            blockBlob.Properties.ContentType = file.FileMime;
            blockBlob.Metadata["filename"] = file.FileName;
            blockBlob.Metadata["filemime"] = file.FileMime;

            // Get stream from file bytes
            Stream stream = new MemoryStream(file.FileBytes);

            // Async upload of stream to Storage
            AsyncCallback UploadCompleted = new AsyncCallback(OnUploadCompleted);
            blockBlob.BeginUploadFromStream(stream, UploadCompleted, blockBlob);

            return true;
        }

        private void OnUploadCompleted(IAsyncResult result)
        {
            CloudBlockBlob blob = (CloudBlockBlob)result.AsyncState;
            blob.SetMetadata();
            blob.EndUploadFromStream(result);
        }
    }
}

//- For API follow from below link: 
//	https://www.c-sharpcorner.com/article/creating-web-api-using-code-first-approach-in-entity-framework/
	
//- Download Azure SDK from

//    https://azure.microsoft.com/en-us/downloads/

//http://www.intstrings.com/ramivemula/articles/file-upload-and-download-to-azure-blob-storage/

