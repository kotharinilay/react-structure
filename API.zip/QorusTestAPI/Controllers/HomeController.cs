﻿using QorusTestAPI.BusinessLayer.Service;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace QorusTestAPI.Controllers
{
    public class HomeController : ApiController
    {
        private readonly UserFileService _userFileServices;

        public HomeController()
        {
            _userFileServices = new UserFileService();
        }

        [HttpGet]
        [ActionName("userfiles")]
        public HttpResponseMessage GetUserFiles()
        {
            var UserFiles = _userFileServices.GetAllFiles();
            return Request.CreateResponse(HttpStatusCode.OK, UserFiles);
        }

        [HttpPost]
        [ActionName("savefile")]
        public async Task<HttpResponseMessage> SaveFile()
        {
            try
            {
                HttpPostedFile file = null;

                if (HttpContext.Current.Request.Files.Count > 0)
                {
                    file = HttpContext.Current.Request.Files.Get("file");
                }
                // Check if we have a file
                if (null == file)
                    return Request.CreateResponse(HttpStatusCode.BadRequest, new
                    {
                        error = true,
                        message = "File not found"
                    });

                // Make sure the file has content
                if (!(file.ContentLength > 0))
                    return Request.CreateResponse(HttpStatusCode.BadRequest, new
                    {
                        error = true,
                        message = "File not found"
                    });

                string category = HttpContext.Current.Request.Params.Get("category");
                DateTime productId = DateTime.Parse(HttpContext.Current.Request.Params.Get("lastreviewed"));

                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Error while saving policy.");
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
