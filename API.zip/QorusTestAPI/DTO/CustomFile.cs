﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QorusTestAPI.DTO
{
    public class CustomFile
    {
        public string FileName { get; set; }
        public byte[] FileBytes { get; set; }
        public string FileMime { get; set; }
    }
}