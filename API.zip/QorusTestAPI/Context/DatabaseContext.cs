﻿using QorusTestAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace QorusTestAPI.Context
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("QorusTestAPI")
        {
            // Database.SetInitializer<DatabaseContext>(new CreateDatabaseIfNotExists<DatabaseContext>());
        }

        public DbSet<UserFile> UserFiles { get; set; }
    }
}