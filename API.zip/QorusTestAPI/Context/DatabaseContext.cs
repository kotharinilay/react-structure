﻿using QorusTestAPI.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace QorusTestAPI.Context
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("QorusTestAPI")
        {
            // Database.SetInitializer<DatabaseContext>(new CreateDatabaseIfNotExists<DatabaseContext>());
        }

        public DbSet<UserFile> UserFiles { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserFile>().Property(t => t.Id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);  //identity col            
            base.OnModelCreating(modelBuilder);
        }
    }
}