﻿using System;
using System.ComponentModel.DataAnnotations;

namespace QorusTestAPI.Models
{
    public class UserFile
    {
        [Key]
        public int Id { get; set; }
        public string FileName { get; set; }
        public int FileSize { get; set; }
        public string Category { get; set; }
        public DateTime LastReviewed { get; set; }
    }
}